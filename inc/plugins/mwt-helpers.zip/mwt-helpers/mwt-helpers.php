<?php if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}
/*
 * Plugin Name: MWT Helpers
 * Plugin URI: http://modernwebtemplates.com
 * Description: This plugin used for theme requirements check
 * Version: 1.2.1
 * Author: MWTemplates
 * Author URI: http://modernwebtemplates.com
 * License:  GPLv2 or later
*/

require_once  plugin_dir_path( __FILE__ ) . 'functions.php';